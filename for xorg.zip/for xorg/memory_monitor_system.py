import focused_window_xdotool
import psutil
import time
import main
import create_excel
import UI_PART
CHECK_INTERVAL=main.CHECK_INTERVAL
MEMORY_LIMIT_MB=main.MEMORY_LIMIT_MB
warning_triggered = False  # Flag to track if the warning has already been triggered
last_focused_window = None  # Store the last focused window to track changes


def monitor_memory(label, wb, sheet):
    """Monitor the memory usage of the focused window's application and system."""
    global warning_triggered, last_focused_window

    while True:
        try:
            # Get the process name of the focused window
            app_name = focused_window_xdotool.get_focused_window_process()

            # If the focused window has changed, reset the warning flag
            if app_name != last_focused_window:
                last_focused_window = app_name
                warning_triggered = False  # Reset for new focused window

            if app_name is None:
                # When no app is focused, show system memory usage
                system_memory = psutil.virtual_memory()
                system_memory_percent = system_memory.percent
                label.config(
                    text=f"No focused window\nSystem Used: {system_memory_percent:.1f}%"
                )
                time.sleep(CHECK_INTERVAL)
                continue

            # Get all processes matching the app name
            processes = [proc for proc in psutil.process_iter(['pid', 'name']) if app_name.lower() in proc.info['name'].lower()]

            if not processes:
                label.config(text=f"No processes for {app_name}")
                time.sleep(CHECK_INTERVAL)
                continue

            # Calculate total memory usage of the app in MB
            total_memory_usage_mb = sum(
                proc.memory_info().rss / (1024 * 1024) for proc in processes
            )

            # Get system memory usage
            system_memory = psutil.virtual_memory()
            system_memory_percent = system_memory.percent

            # Update the label with current usage
            label.config(
                text=(
                    f"{app_name}:\n{total_memory_usage_mb:.2f} MB\n"
                    f"System Used: {system_memory_percent:.1f}%"
                )
            )

            # Get the memory limit for the app from the Excel sheet
            memory_limit = create_excel.get_memory_limit_from_excel(sheet, app_name)
            if memory_limit is None:
                memory_limit = MEMORY_LIMIT_MB

            # Check if memory usage exceeds the limit and if the warning hasn’t been triggered yet
            if total_memory_usage_mb > memory_limit and not warning_triggered:
                message = (f"Warning: {app_name} exceeded memory limit of {memory_limit} MB.\n"
                           f"Current usage: {total_memory_usage_mb:.2f} MB.")
                UI_PART.show_notification(message)
                warning_triggered = True  # Prevent repeated warnings

                # Open a new window to accept a new memory limit
                UI_PART.open_memory_limit_input_window(app_name, memory_limit, wb, sheet)

            time.sleep(CHECK_INTERVAL)

        except psutil.NoSuchProcess:
            time.sleep(CHECK_INTERVAL)
        except Exception as e:
            print(f"Error in monitor_memory: {e}")
            break
