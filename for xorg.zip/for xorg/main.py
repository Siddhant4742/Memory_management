import tkinter as tk
import create_excel
import UI_PART
# Initial Configuration
MEMORY_LIMIT_MB = 500  # Set initial memory limit in MB
CHECK_INTERVAL = 0.5  # Check every half-second
warning_triggered = False  # Flag to track if the warning has already been triggered
last_focused_window = None  # Store the last focused window to track changes


EXCEL_FILE=create_excel.EXCEL_FILE



if __name__ == "__main__":
    # Main application window (hidden)
    root = tk.Tk()
    root.withdraw()

    # Load or create the Excel file
    wb, sheet = create_excel.load_or_create_excel()

    # Create and display the aesthetic pop-up
    UI_PART.create_popup(wb, sheet)

    # Start the Tkinter event loop
    root.mainloop()
