from plyer import notification  # For showing desktop notifications
import tkinter as tk
import create_excel
import memory_monitor_system
import threading

EXCEL_FILE=create_excel.EXCEL_FILE

def show_notification(message):
    """Show system-wide notification using plyer."""
    notification.notify(
        title="Memory Usage Alert",
        message=message,
        timeout=10  # Notification duration in seconds
    )
    print(f"Notification: {message}")


def open_memory_limit_input_window(app_name, current_limit, wb, sheet):
    """Open a pop-up window to allow the user to input a new memory limit."""
    input_window = tk.Toplevel()
    input_window.geometry("300x150")
    input_window.title(f"Set New Memory Limit for {app_name}")
    input_window.attributes("-topmost", True)  # Ensure the window stays on top

    label = tk.Label(
        input_window, 
        text=f"Current Limit: {current_limit} MB\nEnter new memory limit (MB):", 
        font=("Segoe UI", 12)
    )
    label.pack(pady=10)

    entry = tk.Entry(input_window, font=("Segoe UI", 12))
    entry.pack(pady=5)

    def on_submit():
        new_limit = entry.get()
        if new_limit.isdigit():
            new_limit_int = int(new_limit)
            print(f"New memory limit set for {app_name}: {new_limit_int} MB")
            create_excel.update_memory_limit_in_excel(sheet, app_name, new_limit_int)
            wb.save(EXCEL_FILE)  # Save changes
            input_window.destroy()  # Close the input window
        else:
            print("Invalid input, please enter a valid number.")

    submit_button = tk.Button(input_window, text="Submit", command=on_submit, font=("Segoe UI", 12))
    submit_button.pack(pady=10)


def create_popup(wb, sheet):
    """Create an aesthetically improved pop-up window to display memory usage."""
    popup = tk.Toplevel()
    popup.geometry("320x120")  # Set window size
    popup.overrideredirect(True)  # Remove title bar for a modern look
    popup.configure(bg="#2E3440")  # Use a dark background (Nord theme)

    # Get screen dimensions and position the pop-up at the bottom left
    screen_width = popup.winfo_screenwidth()
    screen_height = popup.winfo_screenheight()
    x = 20  # 20 pixels from the left edge
    y = screen_height - 150  # Adjust from the bottom
    popup.geometry(f"320x120+{x}+{y}")

    # Add a label to display the memory usage text
    label = tk.Label(
        popup,
        text="Initializing...",
        font=("Segoe UI", 12, "bold"),
        fg="#D8DEE9",  # Light text color
        bg="#2E3440",  # Match background
        anchor="w"
    )
    label.pack(padx=15, pady=15, fill='both', expand=True)

    # Add a custom close button (×)
    close_button = tk.Button(
        popup,
        text="×",
        font=("Segoe UI", 14, "bold"),
        fg="white",
        bg="#BF616A",
        command=popup.destroy,
        bd=0,
        relief="flat",
        padx=5,
        pady=2
    )
    close_button.place(relx=0.9, rely=0.05)

    # Start the memory monitoring thread that will update the label
    threading.Thread(target=memory_monitor_system.monitor_memory, args=(label, wb, sheet), daemon=True).start()

    return popup
