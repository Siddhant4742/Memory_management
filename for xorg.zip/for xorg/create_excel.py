import openpyxl

EXCEL_FILE = "memory_limits.xlsx"  # Excel file to store app memory limits

def load_or_create_excel():
    try:
        wb = openpyxl.load_workbook(EXCEL_FILE)
        sheet = wb.active
    except FileNotFoundError:
        wb = openpyxl.Workbook()
        sheet = wb.active
        sheet.append(["App Name", "Memory Limit (MB)"])  # Add header row
        wb.save(EXCEL_FILE)
    return wb, sheet

def update_memory_limit_in_excel(sheet, app_name, new_limit):
    """Update the memory limit for the app in Excel."""
    for row in sheet.iter_rows(min_row=2):
        if row[0].value.lower() == app_name.lower():
            row[1].value = new_limit
            break
    else:
        sheet.append([app_name, new_limit])  # If app is not found, add a new row

def get_memory_limit_from_excel(sheet, app_name):
    """Check the current memory limit for the app from Excel."""
    for row in sheet.iter_rows(min_row=2, values_only=True):
        if row[0].lower() == app_name.lower():
            return row[1]
    return None

