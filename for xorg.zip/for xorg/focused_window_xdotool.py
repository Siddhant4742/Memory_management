import subprocess
import psutil

def get_focused_window_process():
    """Get the process name of the currently focused window using xdotool."""
    try:
        # Get the active window ID using xdotool
        window_id = subprocess.run(
            ["xdotool", "getactivewindow"],
            capture_output=True,
            text=True,
            check=True
        ).stdout.strip()

        if window_id:
            # Get the PID of the active window using xdotool
            pid = subprocess.run(
                ["xdotool", "getwindowpid", window_id],
                capture_output=True,
                text=True,
                check=True
            ).stdout.strip()

            if pid.isdigit():
                pid = int(pid)
                process = psutil.Process(pid)
                return process.name()
        return None
    except Exception as e:
        print(f"Error in get_focused_window_process: {e}")
        return None
